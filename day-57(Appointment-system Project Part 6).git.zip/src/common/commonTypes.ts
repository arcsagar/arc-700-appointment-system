

export type btLinkType = "bt-error" | "bt-success" | "bt-warning "

export type headerLinkType = {
    btName: string,
    btPath: string,
    btType: btLinkType
}