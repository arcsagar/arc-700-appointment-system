const UserProfile = () => {
    return (
        <div>
            <h1>User Profile </h1>
        </div>
    )
};

export default UserProfile;