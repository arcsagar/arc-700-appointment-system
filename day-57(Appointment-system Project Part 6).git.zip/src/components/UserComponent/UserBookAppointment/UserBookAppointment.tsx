import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getAllUserEvents } from "../../../store/appointments/appointments-actions";
import AppTable from "../../../common/AppTable";

const UserBookAppointment = () => {
  const { appEvents } = useSelector((state: any) => state.appointments);
  const dispatch: any = useDispatch();
  console.table(appEvents);
  useEffect(() => {
    dispatch(getAllUserEvents());
  }, []);

  const tHead = [
    "allDay",
    "d_city",
    "d_state",
    "d_email",
    "d_name",
    "d_speciality",
    "end",
    "start",
    "title",
  ];

  return (
    <div>
      <h1>User Book Appointments</h1>
      <AppTable appData={appEvents} tHead={tHead} />
    </div>
  );
};

export default UserBookAppointment;
