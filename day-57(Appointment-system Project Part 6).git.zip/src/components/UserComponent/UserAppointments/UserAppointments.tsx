const UserAppointments = () => {
    return (
        <div>
            <h1>User  Appointments</h1>
        </div>
    )
};

export default UserAppointments;