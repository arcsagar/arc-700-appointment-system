const AdminComponent = () => {
    return (
        <h1>Admin</h1>
    )
};
export default AdminComponent