const DoctorAppointments = () => {
    return (
        <div>
            <h1>Doctor  Appointments</h1>
        </div>
    )
};

export default DoctorAppointments;