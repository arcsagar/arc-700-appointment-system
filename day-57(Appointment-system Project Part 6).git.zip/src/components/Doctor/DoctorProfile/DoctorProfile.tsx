const DoctorProfile = () => {
    return (
        <div>
            <h1>Doctor Profile</h1>
        </div>
    )
};

export default DoctorProfile;